project "Core"
   kind "StaticLib"
   language "C++"
   cppdialect "C++20"
   targetdir "Binaries/%{cfg.buildcfg}"
   staticruntime "off"

   files { "Source/**.h", "Source/**.cpp" }

   targetdir ("../Binaries/" .. OutputDir .. "/%{prj.name}")
   objdir ("../Binaries/Intermediates/" .. OutputDir .. "/%{prj.name}")
   
   libdirs {"../Binaries/Dependencies/%{cfg.buildcfg}"}
   
   libdirs {vulkan_sdk_path .. "/Lib"}
   
   includedirs
   {
   "Source",
   "../" .. glm_dir .."/glm",
   vulkan_sdk_path .. "/Include",
   "../" .. glfw_dir .."/include",
   "../" .. spdlog_dir .. "/include"
   }

   filter "action:vs*"
       defines{"_WINSOCK_DEPRECATED_NO_WARNINGS", "_CRT_SECURE_NO_WARNINGS"}
       characterset ("Unicode")

   filter "system:windows"
       systemversion "latest"
       defines { }

   filter "configurations:Debug"
       defines { "DEBUG" }
       runtime "Debug"
       symbols "On"
       warnings "Extra"

   filter "configurations:Release"
       defines { "RELEASE" }
       runtime "Release"
       optimize "On"
       symbols "On"
       fatalwarnings {"All"}
       warnings "Extra"

   filter "configurations:Dist"
       defines { "DIST" }
       runtime "Release"
       optimize "On"
       symbols "Off"
       fatalwarnings {"All"}
       warnings "Extra"